import sys, os
import threading, logging
import pyfiglet
import curses
import time
k = 0
def get_chr(stdscr):
    global k
    while True:
        k = stdscr.getch()
        curses.flushinp()
        if (k == ord('q')):
            exit()
        time.sleep(0.05)

def draw_main_window(stdscr):

    curses.initscr()

    #clean and refresh the screen to get a blank canvas

    stdscr.clear()
    stdscr.refresh()

    t = threading.Thread(target = get_chr, args = (stdscr, ))
    t.setDaemon(True)
    t.start()

    #k = get_chr(stdscr)
    #initialization

    #stdscr.clear()
    height, width = stdscr.getmaxyx()

    if(k == ord(' ')):
        #k = get_chr(stdscr)

        start_time = int(round(time.time() * 1000))
        while(k == ord(' ')):
            while_time = int(round(time.time() * 1000))
            actual_time = while_time - start_time
            #actual_time = "somehsot"[:width - 1]
            actual_time = str(actual_time)
            stdscr.addstr(0, 0, actual_time)
            #k = threading.Thread(target = get_chr, args=(stdscr, ))
            #k.start()
        #final_time = start_timer(stdscr)
        #stdscr.addstr(height - 1, 0, final_time)

'''
def start_timer(stdscr):
    k = 0
    k = stdscr.getch()

    height, width = stdscr.getmaxyx()

    start_time = int(round(time.time() * 1000))
    while(k != ord(' ')):
        while_time = int(round(time.time() * 1000))
        actual_time = start_time - while_time
        actual_time = str(actual_time)
        stdscr.addstr(height - 1, 0, actual_time)
        #strscr.addstr(height - 5, 0, "put")
    return actual_time
'''
def main():
    curses.wrapper(draw_main_window)

if __name__ == '__main__':
    main()
